﻿using System.Collections.Generic;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;
using TMPro;
using Steamworks;
using System.Linq;

namespace MarsFPSKit
{
    namespace UI
    {
        public class Kit_SteamFriends : Kit_MenuFriendsBase
        {
            /// <summary>
            /// Input field for adding a friend
            /// </summary>
            public TMP_InputField addFriendInput;

            /// <summary>
            /// Where the friends go
            /// </summary>
            public RectTransform friendGo;
            /// <summary>
            /// Prefab for the friend list
            /// </summary>
            public GameObject friendPrefab;
            /// <summary>
            /// Currently active buttons
            /// </summary>
            private List<Kit_MenuFriendsButton> currentbuttons = new List<Kit_MenuFriendsButton>();
            /// <summary>
            /// When friend is in a room
            /// </summary>
            public Color friendInGameColor = Color.blue;
            /// <summary>
            /// When friend is online
            /// </summary>
            public Color friendOnlineColor = Color.green;
            /// <summary>
            /// When friend is offline
            /// </summary>
            public Color friendOfflineColor = Color.red;
            /// <summary>
            /// How much time between auto updates?
            /// </summary>
            public float updateInterval = 5f;
            /// <summary>
            /// Update 
            /// </summary>
            private float lastUpdate;

            private List<CSteamID> listOfSteamFriends = new List<CSteamID>();

            public void UpdateFriends()
            {
                if (PhotonNetwork.IsConnectedAndReady && PhotonNetwork.InLobby)
                {
                    int amountOfFriends = SteamFriends.GetFriendCount(EFriendFlags.k_EFriendFlagAll);
                    if (amountOfFriends > 0)
                    {
                        List<string> friends = new List<string>();
                        for (int i = 0; i < amountOfFriends; i++)
                        {
                            CSteamID friend = SteamFriends.GetFriendByIndex(i, EFriendFlags.k_EFriendFlagAll);
                            listOfSteamFriends.Add(friend);
                            friends.Add(friend.m_SteamID.ToString());
                        }
                        //Send to photon
                        PhotonNetwork.FindFriends(friends.ToArray());
                    }
                    else
                    {
                        OnFriendListUpdate(new List<FriendInfo>());
                    }
                }
            }

            public override void AfterLogin()
            {
                UpdateFriends();
            }

            public override void BeforeOpening()
            {
                UpdateFriends();
            }

            public override void OnFriendListUpdate(List<FriendInfo> friendList)
            {
                //Remove currents
                for (int i = 0; i < currentbuttons.Count; i++)
                {
                    Destroy(currentbuttons[i].gameObject);
                }

                currentbuttons = new List<Kit_MenuFriendsButton>();

                for (int i = 0; i < friendList.Count; i++)
                {
                    int id = i;
                    GameObject go = Instantiate(friendPrefab, friendGo, false);
                    //Get button
                    Kit_MenuFriendsButton btn = go.GetComponent<Kit_MenuFriendsButton>();

                    ulong steamId = ulong.Parse(friendList[id].UserId);
                    CSteamID IdOfFriend = listOfSteamFriends.Where(x => x.m_SteamID == steamId).FirstOrDefault();

                    if (IdOfFriend != null) 
                    {
                        //Set name
                        btn.playerName.text = SteamFriends.GetFriendPersonaName(IdOfFriend);
                    }
                    else
                    {
                        btn.playerName.text = friendList[id].UserId;
                    }

                    if (friendList[i].IsOnline)
                    {
                        if (friendList[i].IsInRoom)
                        {
                            btn.onlineState.color = friendInGameColor;
                            btn.joinButton.gameObject.SetActive(true);
                            btn.joinButton.onClick.AddListener(delegate { JoinRoom(friendList[id].Room); });
                        }
                        else
                        {
                            btn.onlineState.color = friendOnlineColor;
                            btn.joinButton.gameObject.SetActive(false);
                        }
                    }
                    else
                    {
                        btn.onlineState.color = friendOfflineColor;
                        btn.joinButton.gameObject.SetActive(false);
                    }

                    //Add to list
                    currentbuttons.Add(btn);
                }
            }

            public void JoinRoom(string room)
            {
                PhotonNetwork.JoinRoom(room);
            }

            private void Update()
            {
                if (PhotonNetwork.IsConnectedAndReady && Time.time > lastUpdate)
                {
                    lastUpdate = Time.time + updateInterval;
                    UpdateFriends();
                }
            }
        }
    }
}